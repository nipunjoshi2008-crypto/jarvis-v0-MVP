import { getMessages, addMessage, createConversation, renameConversation } from '@/lib/conversations'
import { getMemories, extractAndStoreMemories } from '@/lib/memory'
import { webSearch, looksLikeSearchQuery } from '@/lib/search'
import { streamOpenAIChat, callOpenAIJSON } from '@/lib/openai'
import type { Source } from '@/lib/types'

const JARVIS_PERSONA = `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a sophisticated, unflappable AI assistant.
Speak with dry British wit, calm precision, and understated confidence. Address the user as "sir" occasionally, never excessively.
Be concise and genuinely helpful. When you use provided web search results, weave the facts in naturally and cite nothing inline — the interface displays sources separately.
Never invent citations. If search results are empty and you are unsure, say so plainly.`

async function decideSearch(query: string): Promise<string | null> {
  // Fast heuristic first.
  if (!looksLikeSearchQuery(query) && query.length < 200) {
    // Ask the model quickly whether a search is warranted.
    try {
      const parsed = await callOpenAIJSON<{ search: boolean; query?: string }>(
        `Decide if answering this user message accurately REQUIRES current/live web information (news, prices, weather, recent events, real-time facts). Message: """${query}""" Return JSON {"search": boolean, "query": string}. The query should be an optimized search query if search is true.`,
      )
      return parsed.search ? parsed.query || query : null
    } catch {
      return null
    }
  }
  return query
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  if (!body?.message || typeof body.message !== 'string') {
    return new Response(JSON.stringify({ error: 'message is required' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  const userMessage: string = body.message.trim()
  let conversationId: string | undefined = body.conversationId

  // Create a conversation on first turn, titled from the opening line.
  let createdConversation = false
  if (!conversationId) {
    const title = userMessage.slice(0, 60)
    const convo = await createConversation(title || 'New Conversation')
    if (!convo) {
      return new Response(JSON.stringify({ error: 'Failed to create conversation' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      })
    }
    conversationId = convo.id
    createdConversation = true
  }

  // Persist the user message + kick off memory extraction (don't block on it).
  const [history, memories] = await Promise.all([
    getMessages(conversationId),
    getMemories(),
  ])
  await addMessage(conversationId, 'user', userMessage)

  // Decide whether to search and gather sources.
  const searchQuery = await decideSearch(userMessage)
  let sources: Source[] = []
  if (searchQuery) {
    sources = await webSearch(searchQuery, 5)
  }

  // Build the context window.
  const memoryBlock =
    memories.length > 0
      ? `Known long-term facts about the user:\n${memories
          .map((m) => `- ${m.memory}`)
          .join('\n')}`
      : 'No stored long-term memories yet.'

  const searchBlock =
    sources.length > 0
      ? `Live web search results for this query:\n${sources
          .map((s, i) => `[${i + 1}] ${s.title}\n${s.url}\n${s.snippet ?? ''}`)
          .join('\n\n')}`
      : searchQuery
        ? 'A web search was attempted but returned no usable results.'
        : ''

  const systemContent = [JARVIS_PERSONA, memoryBlock, searchBlock]
    .filter(Boolean)
    .join('\n\n')

  const chatMessages = [
    { role: 'system' as const, content: systemContent },
    ...history.slice(-12).map((m) => ({
      role: m.role === 'system' ? ('assistant' as const) : (m.role as 'user' | 'assistant'),
      content: m.content,
    })),
    { role: 'user' as const, content: userMessage },
  ]

  let modelStream: ReadableStream<Uint8Array>
  try {
    modelStream = await streamOpenAIChat(chatMessages)
  } catch (err) {
    console.log('[v0] chat stream error:', (err as Error).message)
    return new Response(JSON.stringify({ error: 'Reasoning engine unavailable' }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  const encoder = new TextEncoder()
  let fullText = ''

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      // First, emit a metadata frame with conversationId + sources.
      const meta = {
        type: 'meta',
        conversationId,
        createdConversation,
        sources,
      }
      controller.enqueue(encoder.encode(JSON.stringify(meta) + '\n'))

      const reader = modelStream.getReader()
      const decoder = new TextDecoder()
      try {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          const chunk = decoder.decode(value, { stream: true })
          fullText += chunk
          controller.enqueue(
            encoder.encode(JSON.stringify({ type: 'token', value: chunk }) + '\n'),
          )
        }
      } catch (err) {
        console.log('[v0] streaming loop error:', (err as Error).message)
      }

      // Persist assistant message with sources.
      await addMessage(conversationId!, 'assistant', fullText, sources.length ? sources : null)

      // Extract memories in the background (after we have the full turn).
      extractAndStoreMemories(userMessage, memories).catch(() => {})

      // Auto-title improvement for brand-new conversations.
      if (createdConversation) {
        renameConversation(conversationId!, userMessage.slice(0, 60)).catch(() => {})
      }

      controller.enqueue(encoder.encode(JSON.stringify({ type: 'done' }) + '\n'))
      controller.close()
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Accel-Buffering': 'no',
    },
  })
}
