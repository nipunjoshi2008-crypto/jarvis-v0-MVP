import { NextResponse } from 'next/server'
import {
  getMessages,
  deleteConversation,
  renameConversation,
} from '@/lib/conversations'

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const messages = await getMessages(id)
  return NextResponse.json({ messages })
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const body = await req.json().catch(() => ({}))
  if (typeof body?.title === 'string' && body.title.trim()) {
    await renameConversation(id, body.title.trim().slice(0, 120))
  }
  return NextResponse.json({ ok: true })
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const ok = await deleteConversation(id)
  return NextResponse.json({ ok })
}
