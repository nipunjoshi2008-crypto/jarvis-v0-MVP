import { NextResponse } from 'next/server'
import { listConversations, createConversation } from '@/lib/conversations'

export async function GET() {
  const conversations = await listConversations()
  return NextResponse.json({ conversations })
}

export async function POST(req: Request) {
  let title = 'New Conversation'
  try {
    const body = await req.json()
    if (typeof body?.title === 'string' && body.title.trim()) {
      title = body.title.trim().slice(0, 120)
    }
  } catch {
    // no body is fine
  }
  const conversation = await createConversation(title)
  if (!conversation) {
    return NextResponse.json({ error: 'Failed to create conversation' }, { status: 500 })
  }
  return NextResponse.json({ conversation })
}
