import { NextResponse } from 'next/server'
import { getMemories, addMemory, deleteMemory } from '@/lib/memory'

export async function GET() {
  const memories = await getMemories()
  return NextResponse.json({ memories })
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}))
  if (typeof body?.memory !== 'string' || !body.memory.trim()) {
    return NextResponse.json({ error: 'memory is required' }, { status: 400 })
  }
  const memory = await addMemory(
    body.memory.trim(),
    typeof body.category === 'string' ? body.category : 'general',
    typeof body.importance === 'number' ? body.importance : 1,
  )
  return NextResponse.json({ memory })
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) {
    return NextResponse.json({ error: 'id is required' }, { status: 400 })
  }
  const ok = await deleteMemory(id)
  return NextResponse.json({ ok })
}
