import { NextResponse } from 'next/server'

// Default cinematic voice ("Adam") if none configured.
const FALLBACK_VOICE_ID = 'pNInz6obpgDQGcFmaJgB'

export async function POST(req: Request) {
  const apiKey = process.env.ELEVENLABS_API_KEY
  if (!apiKey) {
    return NextResponse.json(
      { error: 'ELEVENLABS_API_KEY not configured' },
      { status: 503 },
    )
  }

  const body = await req.json().catch(() => ({}))
  const text: string = (body?.text ?? '').toString().slice(0, 5000)
  if (!text.trim()) {
    return NextResponse.json({ error: 'text is required' }, { status: 400 })
  }

  const voiceId = process.env.ELEVENLABS_VOICE_ID || FALLBACK_VOICE_ID

  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
    {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_turbo_v2_5',
        voice_settings: {
          stability: 0.4,
          similarity_boost: 0.75,
          style: 0.3,
          use_speaker_boost: true,
        },
      }),
    },
  )

  if (!res.ok) {
    const detail = await res.text()
    console.log('[v0] ElevenLabs error:', res.status, detail)
    return NextResponse.json(
      { error: 'TTS failed', status: res.status },
      { status: 502 },
    )
  }

  const audio = await res.arrayBuffer()
  return new Response(audio, {
    headers: {
      'Content-Type': 'audio/mpeg',
      'Cache-Control': 'no-store',
    },
  })
}
