import { Jarvis } from '@/components/jarvis'

export default function Page() {
  return <Jarvis />
}
