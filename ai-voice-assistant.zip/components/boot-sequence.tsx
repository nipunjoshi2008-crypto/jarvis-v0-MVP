'use client'

import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'

const LINES = [
  'INITIALIZING CORE SYSTEMS...',
  'MOUNTING NEURAL INTERFACE...',
  'LOADING LONG-TERM MEMORY BANKS...',
  'CALIBRATING VOICE SYNTHESIS...',
  'ESTABLISHING SECURE UPLINK...',
  'ALL SYSTEMS NOMINAL.',
]

export function BootSequence({ onDone }: { onDone: () => void }) {
  const [visible, setVisible] = useState<number>(0)
  const [complete, setComplete] = useState(false)

  useEffect(() => {
    if (visible < LINES.length) {
      const t = setTimeout(() => setVisible((v) => v + 1), 320)
      return () => clearTimeout(t)
    }
    const done = setTimeout(() => setComplete(true), 550)
    const fade = setTimeout(onDone, 1100)
    return () => {
      clearTimeout(done)
      clearTimeout(fade)
    }
  }, [visible, onDone])

  return (
    <AnimatePresence>
      {!complete && (
        <motion.div
          className="fixed inset-0 z-50 grid place-items-center bg-background"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="hud-grid absolute inset-0 opacity-[0.04]" />
          <div className="flex w-[min(90vw,520px)] flex-col gap-3 px-6 font-mono text-sm">
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 text-center text-2xl font-semibold tracking-[0.5em] text-hud text-glow"
            >
              J.A.R.V.I.S.
            </motion.div>
            {LINES.slice(0, visible).map((line, i) => (
              <motion.div
                key={line}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-3"
              >
                <span className="text-hud">›</span>
                <span
                  className={
                    i === LINES.length - 1
                      ? 'text-hud text-glow'
                      : 'text-muted-foreground'
                  }
                >
                  {line}
                </span>
                {i === LINES.length - 1 && (
                  <span className="ml-auto text-hud">[ OK ]</span>
                )}
              </motion.div>
            ))}
            <div className="mt-4 h-1 w-full overflow-hidden rounded-full bg-secondary">
              <motion.div
                className="h-full bg-hud"
                initial={{ width: '0%' }}
                animate={{ width: `${(visible / LINES.length) * 100}%` }}
                transition={{ ease: 'easeOut' }}
                style={{ boxShadow: '0 0 12px var(--hud)' }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
