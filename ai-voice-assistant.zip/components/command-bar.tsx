'use client'

import { useState } from 'react'
import { Mic, MicOff, Send, Volume2, VolumeX } from 'lucide-react'

export function CommandBar({
  onSend,
  micActive,
  micSupported,
  onToggleMic,
  voiceEnabled,
  onToggleVoice,
  interim,
  disabled,
}: {
  onSend: (text: string) => void
  micActive: boolean
  micSupported: boolean
  onToggleMic: () => void
  voiceEnabled: boolean
  onToggleVoice: () => void
  interim: string
  disabled?: boolean
}) {
  const [value, setValue] = useState('')

  function submit() {
    const text = value.trim()
    if (!text || disabled) return
    onSend(text)
    setValue('')
  }

  return (
    <div className="flex flex-col gap-1.5">
      {(interim || micActive) && (
        <div className="px-1 font-mono text-[11px] tracking-wide text-hud-dim">
          {interim ? `» ${interim}` : '» listening…'}
        </div>
      )}
      <div className="flex items-center gap-2 rounded-lg border border-hud/25 bg-card/70 px-2 py-1.5 backdrop-blur">
        <button
          type="button"
          onClick={onToggleMic}
          disabled={!micSupported}
          aria-label={micActive ? 'Stop listening' : 'Start listening'}
          title={micSupported ? '' : 'Speech recognition not supported in this browser'}
          className={`grid h-9 w-9 place-items-center rounded-md transition-colors ${
            micActive
              ? 'bg-hud/20 text-hud box-glow'
              : 'text-muted-foreground hover:text-hud disabled:opacity-40'
          }`}
        >
          {micActive ? <Mic className="h-4 w-4 animate-hud-pulse" /> : <MicOff className="h-4 w-4" />}
        </button>

        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (
              e.key === 'Enter' &&
              !e.shiftKey &&
              !e.nativeEvent.isComposing &&
              (e as any).keyCode !== 229
            ) {
              e.preventDefault()
              submit()
            }
          }}
          placeholder="Type a command, or speak…"
          className="min-w-0 flex-1 bg-transparent px-1 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none"
        />

        <button
          type="button"
          onClick={onToggleVoice}
          aria-label={voiceEnabled ? 'Mute voice output' : 'Enable voice output'}
          className={`grid h-9 w-9 place-items-center rounded-md transition-colors ${
            voiceEnabled ? 'text-hud' : 'text-muted-foreground hover:text-hud'
          }`}
        >
          {voiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>

        <button
          type="button"
          onClick={submit}
          disabled={!value.trim() || disabled}
          aria-label="Send"
          className="grid h-9 w-9 place-items-center rounded-md bg-hud/15 text-hud transition-colors hover:bg-hud/25 disabled:opacity-40"
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
