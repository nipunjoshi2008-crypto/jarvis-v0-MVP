'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Trash2, MessageSquare } from 'lucide-react'
import type { Conversation } from '@/lib/types'
import { PanelHeader } from './transcript-panel'

export function ConversationPanel({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
}: {
  conversations: Conversation[]
  activeId: string | null
  onSelect: (id: string) => void
  onNew: () => void
  onDelete: (id: string) => void
}) {
  return (
    <div className="flex h-full flex-col">
      <PanelHeader title="SESSIONS" meta={`${conversations.length}`} />
      <div className="px-3 pt-3">
        <button
          onClick={onNew}
          className="flex w-full items-center justify-center gap-2 rounded-md border border-hud/40 bg-hud/10 py-2 font-mono text-xs tracking-widest text-hud transition-colors hover:bg-hud/20"
        >
          <Plus className="h-3.5 w-3.5" />
          NEW SESSION
        </button>
      </div>
      <div className="custom-scroll flex-1 space-y-1.5 overflow-y-auto px-3 py-3">
        {conversations.length === 0 && (
          <p className="mt-4 text-center font-mono text-[11px] text-muted-foreground">
            No sessions yet.
          </p>
        )}
        <AnimatePresence initial={false}>
          {conversations.map((c) => {
            const active = c.id === activeId
            return (
              <motion.div
                key={c.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, height: 0 }}
                className={`group flex items-center gap-2 rounded-md border px-2.5 py-2 transition-colors ${
                  active
                    ? 'border-hud/50 bg-hud/10'
                    : 'border-transparent hover:border-hud/20 hover:bg-card/50'
                }`}
              >
                <button
                  onClick={() => onSelect(c.id)}
                  className="flex min-w-0 flex-1 items-center gap-2 text-left"
                >
                  <MessageSquare
                    className={`h-3.5 w-3.5 shrink-0 ${active ? 'text-hud' : 'text-muted-foreground'}`}
                  />
                  <span
                    className={`truncate text-xs ${active ? 'text-foreground' : 'text-muted-foreground'}`}
                  >
                    {c.title}
                  </span>
                </button>
                <button
                  onClick={() => onDelete(c.id)}
                  className="text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                  aria-label="Delete session"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </div>
  )
}
