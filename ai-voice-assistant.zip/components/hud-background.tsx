export function HudBackground() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
      {/* Radial vignette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 45%, oklch(0.24 0.05 240) 0%, oklch(0.16 0.03 250) 55%, oklch(0.12 0.025 255) 100%)',
        }}
      />
      {/* Fine grid */}
      <div className="hud-grid absolute inset-0" />
      {/* Scanlines */}
      <div className="hud-scanlines absolute inset-0 opacity-40" />
      {/* Corner brackets */}
      <Corner className="left-4 top-4" />
      <Corner className="right-4 top-4 rotate-90" />
      <Corner className="bottom-4 left-4 -rotate-90" />
      <Corner className="bottom-4 right-4 rotate-180" />
    </div>
  )
}

function Corner({ className }: { className?: string }) {
  return (
    <svg
      className={`absolute h-16 w-16 text-hud-dim/50 ${className ?? ''}`}
      viewBox="0 0 64 64"
      fill="none"
    >
      <path d="M2 20 V2 H20" stroke="currentColor" strokeWidth="1.5" />
      <path d="M2 32 V28" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="6" cy="6" r="2" fill="currentColor" />
    </svg>
  )
}
