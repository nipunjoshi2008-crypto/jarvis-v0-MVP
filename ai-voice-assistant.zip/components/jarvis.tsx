'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import useSWR from 'swr'
import { BootSequence } from './boot-sequence'
import { HudBackground } from './hud-background'
import { ReactorCore, type CoreState } from './reactor-core'
import { TranscriptPanel } from './transcript-panel'
import { MemoryPanel } from './memory-panel'
import { ConversationPanel } from './conversation-panel'
import { CommandBar } from './command-bar'
import { useSpeechRecognition } from '@/hooks/use-speech-recognition'
import { useVoicePlayback } from '@/hooks/use-voice-playback'
import type { Conversation, Message, Source } from '@/lib/types'

const fetcher = (url: string) => fetch(url).then((r) => r.json())
const WAKE_WORD = /\b(jarvis|hey jarvis|okay jarvis)\b/i

export function Jarvis() {
  const [booted, setBooted] = useState(false)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [streaming, setStreaming] = useState<{ content: string; sources: Source[] } | null>(null)
  const [thinking, setThinking] = useState(false)
  const [interim, setInterim] = useState('')
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [memoryRefresh, setMemoryRefresh] = useState(0)
  const [wakeArmed, setWakeArmed] = useState(false)

  const { speak, stop: stopSpeaking, speaking, level, setEnabled } = useVoicePlayback()

  // Conversation list
  const { data: convData, mutate: mutateConvos } = useSWR<{ conversations: Conversation[] }>(
    '/api/conversations',
    fetcher,
  )
  const conversations = convData?.conversations ?? []

  useEffect(() => {
    setEnabled(voiceEnabled)
    if (!voiceEnabled) stopSpeaking()
  }, [voiceEnabled, setEnabled, stopSpeaking])

  // Load messages when switching conversations
  useEffect(() => {
    if (!activeId) {
      setMessages([])
      return
    }
    let cancelled = false
    fetcher(`/api/conversations/${activeId}`).then((d) => {
      if (!cancelled) setMessages(d.messages ?? [])
    })
    return () => {
      cancelled = true
    }
  }, [activeId])

  const sendMessage = useCallback(
    async (text: string) => {
      if (thinking) return
      setInterim('')
      stopSpeaking()

      const optimistic: Message = {
        id: `tmp-${Date.now()}`,
        conversation_id: activeId ?? 'pending',
        role: 'user',
        content: text,
        created_at: new Date().toISOString(),
      }
      setMessages((m) => [...m, optimistic])
      setThinking(true)
      setStreaming({ content: '', sources: [] })

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: text, conversationId: activeId }),
        })

        if (!res.body) throw new Error('no stream')

        const reader = res.body.getReader()
        const decoder = new TextDecoder()
        let buffer = ''
        let convoId = activeId
        let full = ''
        let sources: Source[] = []

        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })
          const lines = buffer.split('\n')
          buffer = lines.pop() ?? ''
          for (const line of lines) {
            if (!line.trim()) continue
            let frame: any
            try {
              frame = JSON.parse(line)
            } catch {
              continue
            }
            if (frame.type === 'meta') {
              convoId = frame.conversationId
              sources = frame.sources ?? []
              if (frame.createdConversation) {
                mutateConvos()
              }
              if (!activeId && convoId) setActiveId(convoId)
              setStreaming({ content: '', sources })
            } else if (frame.type === 'token') {
              full += frame.value
              setStreaming({ content: full, sources })
            } else if (frame.type === 'done') {
              // finalize below
            }
          }
        }

        // Commit final assistant message locally
        const assistantMsg: Message = {
          id: `a-${Date.now()}`,
          conversation_id: convoId ?? 'pending',
          role: 'assistant',
          content: full,
          sources: sources.length ? sources : null,
          created_at: new Date().toISOString(),
        }
        setMessages((m) => [...m, assistantMsg])
        setStreaming(null)
        setThinking(false)
        setMemoryRefresh((n) => n + 1)
        mutateConvos()

        if (voiceEnabled && full.trim()) {
          speak(full)
        }
      } catch (err) {
        console.log('[v0] sendMessage error:', (err as Error).message)
        setStreaming(null)
        setThinking(false)
        setMessages((m) => [
          ...m,
          {
            id: `err-${Date.now()}`,
            conversation_id: activeId ?? 'pending',
            role: 'assistant',
            content: 'Apologies, sir — I encountered a fault reaching the reasoning core.',
            created_at: new Date().toISOString(),
          },
        ])
      }
    },
    [activeId, thinking, voiceEnabled, speak, stopSpeaking, mutateConvos],
  )

  // Speech recognition. Wake word arms a command; without arming we still
  // accept direct speech when the mic is toggled on (armed=true always once toggled).
  const handleFinal = useCallback(
    (text: string) => {
      const stripped = text.replace(WAKE_WORD, '').trim()
      if (WAKE_WORD.test(text)) {
        setWakeArmed(true)
        if (stripped) {
          setWakeArmed(false)
          sendMessage(stripped)
        }
        return
      }
      // If mic is on, treat any final utterance as a command.
      if (stripped) {
        setWakeArmed(false)
        sendMessage(text.trim())
      }
    },
    [sendMessage],
  )

  const { listening, supported, start, stop } = useSpeechRecognition({
    onFinal: handleFinal,
    onInterim: setInterim,
    continuous: true,
  })

  const toggleMic = useCallback(() => {
    if (listening) {
      stop()
      setInterim('')
      setWakeArmed(false)
    } else {
      start()
    }
  }, [listening, start, stop])

  const newSession = useCallback(() => {
    setActiveId(null)
    setMessages([])
    setStreaming(null)
    stopSpeaking()
  }, [stopSpeaking])

  const deleteSession = useCallback(
    async (id: string) => {
      await fetch(`/api/conversations/${id}`, { method: 'DELETE' })
      if (id === activeId) newSession()
      mutateConvos()
    },
    [activeId, newSession, mutateConvos],
  )

  const coreState: CoreState = speaking
    ? 'speaking'
    : thinking
      ? 'thinking'
      : listening
        ? 'listening'
        : 'idle'

  return (
    <>
      {!booted && <BootSequence onDone={() => setBooted(true)} />}
      <HudBackground />

      <main className="relative z-10 mx-auto flex h-dvh max-w-[1500px] flex-col gap-3 p-3 md:p-4">
        {/* Top status strip */}
        <header className="flex items-center justify-between rounded-lg border border-hud/20 bg-card/40 px-4 py-2 backdrop-blur">
          <div className="flex items-center gap-3">
            <span className="h-2 w-2 animate-hud-pulse rounded-full bg-hud" />
            <h1 className="font-mono text-sm tracking-[0.35em] text-hud text-glow">
              J.A.R.V.I.S.
            </h1>
          </div>
          <div className="hidden items-center gap-6 font-mono text-[10px] tracking-[0.25em] text-muted-foreground sm:flex">
            <span>CORE: {coreState.toUpperCase()}</span>
            <span>MIC: {listening ? 'LIVE' : 'OFF'}</span>
            <span>VOICE: {voiceEnabled ? 'ON' : 'MUTED'}</span>
            <Clock />
          </div>
        </header>

        {/* Body: three columns on desktop */}
        <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[240px_1fr_260px]">
          {/* Left: sessions */}
          <aside className="hidden min-h-0 rounded-lg border border-hud/20 bg-card/40 backdrop-blur lg:block">
            <ConversationPanel
              conversations={conversations}
              activeId={activeId}
              onSelect={setActiveId}
              onNew={newSession}
              onDelete={deleteSession}
            />
          </aside>

          {/* Center: reactor + transcript */}
          <section className="flex min-h-0 flex-col gap-3">
            <div className="flex flex-col items-center justify-center rounded-lg border border-hud/20 bg-card/30 py-4 backdrop-blur">
              <ReactorCore
                state={coreState}
                level={level}
                onActivate={toggleMic}
              />
              {wakeArmed && (
                <p className="mt-2 font-mono text-[11px] tracking-widest text-hud animate-hud-pulse">
                  AWAITING COMMAND…
                </p>
              )}
            </div>
            <div className="min-h-0 flex-1 rounded-lg border border-hud/20 bg-card/40 backdrop-blur">
              <TranscriptPanel messages={messages} streaming={streaming} />
            </div>
            <CommandBar
              onSend={sendMessage}
              micActive={listening}
              micSupported={supported}
              onToggleMic={toggleMic}
              voiceEnabled={voiceEnabled}
              onToggleVoice={() => setVoiceEnabled((v) => !v)}
              interim={interim}
              disabled={thinking}
            />
          </section>

          {/* Right: memory */}
          <aside className="hidden min-h-0 rounded-lg border border-hud/20 bg-card/40 backdrop-blur lg:block">
            <MemoryPanel refreshKey={memoryRefresh} />
          </aside>
        </div>
      </main>
    </>
  )
}

function Clock() {
  const [time, setTime] = useState('')
  useEffect(() => {
    const update = () =>
      setTime(
        new Date().toLocaleTimeString('en-GB', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
      )
    update()
    const id = setInterval(update, 1000)
    return () => clearInterval(id)
  }, [])
  return <span className="tabular-nums text-hud">{time}</span>
}
