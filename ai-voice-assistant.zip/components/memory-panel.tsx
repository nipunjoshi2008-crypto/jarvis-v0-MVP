'use client'

import useSWR from 'swr'
import { motion, AnimatePresence } from 'framer-motion'
import { Trash2, BrainCircuit } from 'lucide-react'
import type { Memory } from '@/lib/types'
import { PanelHeader } from './transcript-panel'

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export function MemoryPanel({ refreshKey }: { refreshKey: number }) {
  const { data, mutate } = useSWR<{ memories: Memory[] }>(
    ['/api/memory', refreshKey],
    ([url]) => fetcher(url as string),
    { refreshInterval: 0 },
  )

  const memories = data?.memories ?? []

  async function remove(id: string) {
    await fetch(`/api/memory?id=${id}`, { method: 'DELETE' })
    mutate()
  }

  return (
    <div className="flex h-full flex-col">
      <PanelHeader title="MEMORY BANK" meta={`${memories.length} REC`} />
      <div className="custom-scroll flex-1 space-y-2 overflow-y-auto px-3 py-3">
        {memories.length === 0 && (
          <div className="mt-6 flex flex-col items-center gap-2 text-center">
            <BrainCircuit className="h-6 w-6 text-hud-dim" />
            <p className="font-mono text-[11px] leading-relaxed text-muted-foreground">
              No long-term memories yet.
              <br />
              I&apos;ll retain what matters as we talk.
            </p>
          </div>
        )}
        <AnimatePresence initial={false}>
          {memories.map((m) => (
            <motion.div
              key={m.id}
              layout
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 12 }}
              className="group relative rounded-md border border-hud/20 bg-card/50 px-2.5 py-2"
            >
              <div className="mb-1 flex items-center gap-2">
                <span className="rounded-sm bg-hud/15 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-hud">
                  {m.category}
                </span>
                <span className="font-mono text-[9px] text-muted-foreground">
                  {'★'.repeat(Math.max(1, Math.min(5, m.importance)))}
                </span>
                <button
                  onClick={() => remove(m.id)}
                  className="ml-auto text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                  aria-label="Forget this memory"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
              <p className="text-xs leading-relaxed text-foreground/90">{m.memory}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}
