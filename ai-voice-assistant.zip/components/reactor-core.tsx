'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'

export type CoreState = 'idle' | 'listening' | 'thinking' | 'speaking'

const STATE_LABEL: Record<CoreState, string> = {
  idle: 'STANDBY',
  listening: 'LISTENING',
  thinking: 'PROCESSING',
  speaking: 'SPEAKING',
}

export function ReactorCore({
  state,
  level = 0,
  onActivate,
}: {
  state: CoreState
  /** 0..1 audio level for reactive rings */
  level?: number
  onActivate?: () => void
}) {
  const active = state !== 'idle'
  const pulse = 1 + level * 0.18

  return (
    <div className="relative flex flex-col items-center gap-6 select-none">
      <button
        type="button"
        onClick={onActivate}
        aria-label="Activate assistant"
        className="group relative grid place-items-center focus:outline-none"
        style={{ width: 300, height: 300 }}
      >
        {/* Outer rotating rings */}
        <Ring size={300} className="animate-spin-slower" dashed />
        <Ring size={252} className="animate-spin-slow" ticks />
        <Ring size={210} className="animate-spin-med" segmented />

        {/* Reactive glow disc */}
        <motion.div
          className="absolute rounded-full box-glow"
          animate={{ scale: active ? pulse : 1 }}
          transition={{ type: 'spring', stiffness: 120, damping: 14 }}
          style={{
            width: 168,
            height: 168,
            background:
              'radial-gradient(circle, oklch(0.9 0.15 200 / 0.55) 0%, oklch(0.6 0.13 215 / 0.15) 60%, transparent 72%)',
          }}
        />

        {/* Audio-reactive waveform ring (canvas) */}
        <Waveform state={state} level={level} />

        {/* Inner triangle emblem */}
        <div className="absolute grid place-items-center" style={{ width: 96, height: 96 }}>
          <svg viewBox="0 0 100 100" className="h-full w-full text-hud text-glow">
            <motion.polygon
              points="50,14 86,74 14,74"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              animate={{ opacity: active ? [0.6, 1, 0.6] : 0.75 }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <circle cx="50" cy="54" r="8" fill="currentColor" opacity="0.9" />
          </svg>
        </div>
      </button>

      <div className="flex flex-col items-center gap-1">
        <span className="font-mono text-xs tracking-[0.4em] text-hud text-glow">
          {STATE_LABEL[state]}
        </span>
        <span className="font-mono text-[10px] tracking-[0.3em] text-muted-foreground">
          J.A.R.V.I.S.
        </span>
      </div>
    </div>
  )
}

function Ring({
  size,
  className,
  dashed,
  ticks,
  segmented,
}: {
  size: number
  className?: string
  dashed?: boolean
  ticks?: boolean
  segmented?: boolean
}) {
  return (
    <div
      className={`absolute rounded-full border border-hud/20 ${className ?? ''}`}
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 100 100" className="h-full w-full text-hud/60">
        {dashed && (
          <circle
            cx="50"
            cy="50"
            r="48"
            fill="none"
            stroke="currentColor"
            strokeWidth="0.5"
            strokeDasharray="2 4"
          />
        )}
        {segmented && (
          <circle
            cx="50"
            cy="50"
            r="47"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeDasharray="30 14"
          />
        )}
        {ticks &&
          Array.from({ length: 48 }).map((_, i) => {
            const long = i % 4 === 0
            return (
              <line
                key={i}
                x1="50"
                y1="2"
                x2="50"
                y2={long ? '7' : '5'}
                stroke="currentColor"
                strokeWidth="0.5"
                transform={`rotate(${(i / 48) * 360} 50 50)`}
              />
            )
          })}
      </svg>
    </div>
  )
}

function Waveform({ state, level }: { state: CoreState; level: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number>(0)
  const phaseRef = useRef(0)
  const levelRef = useRef(level)
  levelRef.current = level

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const dpr = window.devicePixelRatio || 1
    const s = 192
    canvas.width = s * dpr
    canvas.height = s * dpr
    ctx.scale(dpr, dpr)

    const draw = () => {
      ctx.clearRect(0, 0, s, s)
      const cx = s / 2
      const cy = s / 2
      const baseR = 78
      const active = state !== 'idle'
      const amp = active ? 6 + levelRef.current * 22 : 2.5
      phaseRef.current += state === 'thinking' ? 0.09 : 0.05

      ctx.beginPath()
      const points = 120
      for (let i = 0; i <= points; i++) {
        const a = (i / points) * Math.PI * 2
        const wobble =
          Math.sin(a * 6 + phaseRef.current) * amp * 0.5 +
          Math.sin(a * 11 - phaseRef.current * 1.4) * amp * 0.5
        const r = baseR + wobble
        const x = cx + Math.cos(a) * r
        const y = cy + Math.sin(a) * r
        if (i === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
      }
      ctx.closePath()
      ctx.strokeStyle = active
        ? 'oklch(0.85 0.17 200 / 0.9)'
        : 'oklch(0.7 0.12 210 / 0.5)'
      ctx.lineWidth = 1.5
      ctx.shadowColor = 'oklch(0.85 0.17 200 / 0.8)'
      ctx.shadowBlur = active ? 12 : 4
      ctx.stroke()

      rafRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(rafRef.current)
  }, [state])

  return (
    <canvas
      ref={canvasRef}
      className="absolute"
      style={{ width: 192, height: 192 }}
      aria-hidden
    />
  )
}
