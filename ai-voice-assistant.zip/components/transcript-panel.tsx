'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import type { Message, Source } from '@/lib/types'
import { ExternalLink } from 'lucide-react'

export function TranscriptPanel({
  messages,
  streaming,
}: {
  messages: Message[]
  streaming?: { content: string; sources: Source[] } | null
}) {
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streaming?.content])

  const empty = messages.length === 0 && !streaming

  return (
    <div className="flex h-full flex-col">
      <PanelHeader title="TRANSCRIPT" meta={`${messages.length} MSG`} />
      <div className="custom-scroll flex-1 space-y-4 overflow-y-auto px-4 py-4">
        {empty && (
          <p className="mt-8 text-center font-mono text-xs leading-relaxed text-muted-foreground">
            Awaiting instruction, sir.
            <br />
            Speak or type to begin.
          </p>
        )}
        {messages.map((m) => (
          <Bubble key={m.id} role={m.role} content={m.content} sources={m.sources ?? undefined} />
        ))}
        {streaming && (
          <Bubble
            role="assistant"
            content={streaming.content || '…'}
            sources={streaming.sources}
            live
          />
        )}
        <div ref={endRef} />
      </div>
    </div>
  )
}

function Bubble({
  role,
  content,
  sources,
  live,
}: {
  role: string
  content: string
  sources?: Source[]
  live?: boolean
}) {
  const isUser = role === 'user'
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex flex-col gap-1 ${isUser ? 'items-end' : 'items-start'}`}
    >
      <span className="font-mono text-[10px] tracking-[0.25em] text-muted-foreground">
        {isUser ? 'YOU' : 'J.A.R.V.I.S.'}
      </span>
      <div
        className={`max-w-[92%] rounded-md px-3 py-2 text-sm leading-relaxed ${
          isUser
            ? 'bg-secondary text-secondary-foreground'
            : 'border border-hud/25 bg-card/60 text-foreground'
        }`}
      >
        {content}
        {live && <span className="ml-0.5 inline-block h-4 w-1.5 animate-hud-pulse bg-hud align-middle" />}
      </div>
      {sources && sources.length > 0 && (
        <div className="mt-1 flex max-w-[92%] flex-wrap gap-1.5">
          {sources.slice(0, 5).map((s, i) => (
            <a
              key={i}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              title={s.snippet ?? s.title}
              className="flex items-center gap-1 rounded border border-hud/25 bg-background/50 px-1.5 py-0.5 font-mono text-[10px] text-hud-dim transition-colors hover:border-hud/60 hover:text-hud"
            >
              <ExternalLink className="h-2.5 w-2.5" />
              {new URL(s.url || 'https://x').hostname.replace('www.', '')}
            </a>
          ))}
        </div>
      )}
    </motion.div>
  )
}

export function PanelHeader({ title, meta }: { title: string; meta?: string }) {
  return (
    <div className="flex items-center justify-between border-b border-hud/20 px-4 py-2.5">
      <div className="flex items-center gap-2">
        <span className="h-1.5 w-1.5 animate-hud-pulse rounded-full bg-hud" />
        <span className="font-mono text-xs tracking-[0.3em] text-hud">{title}</span>
      </div>
      {meta && (
        <span className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground">
          {meta}
        </span>
      )}
    </div>
  )
}
