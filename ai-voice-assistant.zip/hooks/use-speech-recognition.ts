'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

// Minimal typing for the Web Speech API (not in default TS lib).
type SpeechRecognitionResult = {
  transcript: string
  isFinal: boolean
}

interface Options {
  onFinal: (text: string) => void
  onInterim?: (text: string) => void
  continuous?: boolean
}

export function useSpeechRecognition({ onFinal, onInterim, continuous }: Options) {
  const [listening, setListening] = useState(false)
  const [supported, setSupported] = useState(true)
  const recognitionRef = useRef<any>(null)
  const shouldRestartRef = useRef(false)
  const onFinalRef = useRef(onFinal)
  const onInterimRef = useRef(onInterim)
  onFinalRef.current = onFinal
  onInterimRef.current = onInterim

  useEffect(() => {
    const SR =
      (typeof window !== 'undefined' &&
        ((window as any).SpeechRecognition ||
          (window as any).webkitSpeechRecognition)) ||
      null
    if (!SR) {
      setSupported(false)
      return
    }

    const rec = new SR()
    rec.lang = 'en-US'
    rec.interimResults = true
    rec.continuous = !!continuous
    rec.maxAlternatives = 1

    rec.onresult = (event: any) => {
      let interim = ''
      let final = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const r: SpeechRecognitionResult = {
          transcript: event.results[i][0].transcript,
          isFinal: event.results[i].isFinal,
        }
        if (r.isFinal) final += r.transcript
        else interim += r.transcript
      }
      if (interim && onInterimRef.current) onInterimRef.current(interim)
      if (final.trim()) onFinalRef.current(final.trim())
    }

    rec.onend = () => {
      if (shouldRestartRef.current) {
        try {
          rec.start()
        } catch {
          setListening(false)
        }
      } else {
        setListening(false)
      }
    }

    rec.onerror = (e: any) => {
      if (e.error === 'no-speech' || e.error === 'aborted') return
      console.log('[v0] speech recognition error:', e.error)
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        shouldRestartRef.current = false
        setListening(false)
      }
    }

    recognitionRef.current = rec
    return () => {
      shouldRestartRef.current = false
      try {
        rec.stop()
      } catch {}
    }
  }, [continuous])

  const start = useCallback(() => {
    const rec = recognitionRef.current
    if (!rec) return
    shouldRestartRef.current = !!continuous
    try {
      rec.start()
      setListening(true)
    } catch {
      // already started
    }
  }, [continuous])

  const stop = useCallback(() => {
    const rec = recognitionRef.current
    if (!rec) return
    shouldRestartRef.current = false
    try {
      rec.stop()
    } catch {}
    setListening(false)
  }, [])

  return { listening, supported, start, stop }
}
