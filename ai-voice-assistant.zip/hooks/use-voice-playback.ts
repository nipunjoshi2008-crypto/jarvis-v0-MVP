'use client'

import { useCallback, useRef, useState } from 'react'

/**
 * Plays ElevenLabs TTS audio for a piece of text and exposes a live 0..1
 * amplitude level (via WebAudio analyser) so the reactor can react.
 * Falls back to the browser SpeechSynthesis voice if TTS is unavailable.
 */
export function useVoicePlayback() {
  const [speaking, setSpeaking] = useState(false)
  const [level, setLevel] = useState(0)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const ctxRef = useRef<AudioContext | null>(null)
  const rafRef = useRef<number>(0)
  const enabledRef = useRef(true)

  const setEnabled = useCallback((v: boolean) => {
    enabledRef.current = v
  }, [])

  const stop = useCallback(() => {
    cancelAnimationFrame(rafRef.current)
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current = null
    }
    if (typeof window !== 'undefined') window.speechSynthesis?.cancel()
    setSpeaking(false)
    setLevel(0)
  }, [])

  const speak = useCallback(
    async (text: string) => {
      if (!enabledRef.current || !text.trim()) return
      stop()
      setSpeaking(true)

      try {
        const res = await fetch('/api/voice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text }),
        })

        if (!res.ok) throw new Error(`voice ${res.status}`)

        const blob = await res.blob()
        const url = URL.createObjectURL(blob)
        const audio = new Audio(url)
        audio.crossOrigin = 'anonymous'
        audioRef.current = audio

        // Set up analyser for reactive level.
        try {
          const AC =
            (window as any).AudioContext || (window as any).webkitAudioContext
          const ctx: AudioContext = ctxRef.current ?? new AC()
          ctxRef.current = ctx
          if (ctx.state === 'suspended') await ctx.resume()
          const source = ctx.createMediaElementSource(audio)
          const analyser = ctx.createAnalyser()
          analyser.fftSize = 256
          source.connect(analyser)
          analyser.connect(ctx.destination)
          const buf = new Uint8Array(analyser.frequencyBinCount)

          const tick = () => {
            analyser.getByteFrequencyData(buf)
            let sum = 0
            for (let i = 0; i < buf.length; i++) sum += buf[i]
            setLevel(Math.min(1, sum / buf.length / 90))
            rafRef.current = requestAnimationFrame(tick)
          }
          tick()
        } catch {
          // analyser optional
        }

        audio.onended = () => {
          cancelAnimationFrame(rafRef.current)
          URL.revokeObjectURL(url)
          setSpeaking(false)
          setLevel(0)
        }
        await audio.play()
      } catch (err) {
        console.log('[v0] TTS failed, falling back to SpeechSynthesis:', (err as Error).message)
        // Browser fallback
        try {
          const u = new SpeechSynthesisUtterance(text)
          u.rate = 1.02
          u.pitch = 0.9
          u.onend = () => {
            setSpeaking(false)
            setLevel(0)
          }
          // fake a gentle level pulse
          let t = 0
          const pulse = () => {
            t += 0.15
            setLevel(0.3 + Math.abs(Math.sin(t)) * 0.4)
            rafRef.current = requestAnimationFrame(pulse)
          }
          u.onstart = pulse
          u.onend = () => {
            cancelAnimationFrame(rafRef.current)
            setSpeaking(false)
            setLevel(0)
          }
          window.speechSynthesis.speak(u)
        } catch {
          setSpeaking(false)
        }
      }
    },
    [stop],
  )

  return { speak, stop, speaking, level, setEnabled }
}
