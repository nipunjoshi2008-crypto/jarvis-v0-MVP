import { getAdminClient, DEFAULT_USER_ID } from './supabase/admin'
import type { Conversation, Message, Role, Source } from './types'

export async function listConversations(
  userId = DEFAULT_USER_ID,
): Promise<Conversation[]> {
  const supabase = getAdminClient()
  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false })

  if (error) {
    console.log('[v0] listConversations error:', error.message)
    return []
  }
  return (data as Conversation[]) ?? []
}

export async function createConversation(
  title = 'New Conversation',
  userId = DEFAULT_USER_ID,
): Promise<Conversation | null> {
  const supabase = getAdminClient()
  const { data, error } = await supabase
    .from('conversations')
    .insert({ user_id: userId, title })
    .select()
    .single()

  if (error) {
    console.log('[v0] createConversation error:', error.message)
    return null
  }
  return data as Conversation
}

export async function getMessages(
  conversationId: string,
): Promise<Message[]> {
  const supabase = getAdminClient()
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })

  if (error) {
    console.log('[v0] getMessages error:', error.message)
    return []
  }
  return (data as Message[]) ?? []
}

export async function addMessage(
  conversationId: string,
  role: Role,
  content: string,
  sources?: Source[] | null,
): Promise<Message | null> {
  const supabase = getAdminClient()
  const { data, error } = await supabase
    .from('messages')
    .insert({ conversation_id: conversationId, role, content, sources: sources ?? null })
    .select()
    .single()

  if (error) {
    console.log('[v0] addMessage error:', error.message)
    return null
  }

  // bump conversation updated_at
  await supabase
    .from('conversations')
    .update({ updated_at: new Date().toISOString() })
    .eq('id', conversationId)

  return data as Message
}

export async function renameConversation(id: string, title: string) {
  const supabase = getAdminClient()
  await supabase.from('conversations').update({ title }).eq('id', id)
}

export async function deleteConversation(id: string): Promise<boolean> {
  const supabase = getAdminClient()
  const { error } = await supabase.from('conversations').delete().eq('id', id)
  if (error) {
    console.log('[v0] deleteConversation error:', error.message)
    return false
  }
  return true
}
