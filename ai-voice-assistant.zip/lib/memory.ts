import { getAdminClient, DEFAULT_USER_ID } from './supabase/admin'
import type { Memory } from './types'
import { callOpenAIJSON } from './openai'

export async function getMemories(userId = DEFAULT_USER_ID): Promise<Memory[]> {
  const supabase = getAdminClient()
  const { data, error } = await supabase
    .from('memories')
    .select('*')
    .eq('user_id', userId)
    .order('importance', { ascending: false })
    .order('updated_at', { ascending: false })
    .limit(100)

  if (error) {
    console.log('[v0] getMemories error:', error.message)
    return []
  }
  return (data as Memory[]) ?? []
}

export async function addMemory(
  memory: string,
  category = 'general',
  importance = 1,
  userId = DEFAULT_USER_ID,
): Promise<Memory | null> {
  const supabase = getAdminClient()
  const { data, error } = await supabase
    .from('memories')
    .insert({ user_id: userId, memory, category, importance })
    .select()
    .single()

  if (error) {
    console.log('[v0] addMemory error:', error.message)
    return null
  }
  return data as Memory
}

export async function deleteMemory(id: string): Promise<boolean> {
  const supabase = getAdminClient()
  const { error } = await supabase.from('memories').delete().eq('id', id)
  if (error) {
    console.log('[v0] deleteMemory error:', error.message)
    return false
  }
  return true
}

/**
 * Use the model to extract durable, personal facts worth remembering from a
 * user message. Returns nothing for small talk. Stores extracted facts.
 */
export async function extractAndStoreMemories(
  userMessage: string,
  existing: Memory[],
): Promise<Memory[]> {
  const existingList = existing.map((m) => `- ${m.memory}`).join('\n') || '(none yet)'

  const prompt = `You maintain a long-term memory for a personal AI assistant.
From the user's latest message, extract ONLY durable, personally-relevant facts worth remembering long term (preferences, identity, relationships, goals, recurring context). Do NOT store transient questions, small talk, or one-off requests.

Existing memories (do not duplicate these):
${existingList}

User message:
"""${userMessage}"""

Return strict JSON: {"memories": [{"memory": string, "category": string, "importance": number 1-5}]}. Return an empty array if nothing is worth storing.`

  try {
    const parsed = await callOpenAIJSON<{
      memories?: Array<{ memory: string; category?: string; importance?: number }>
    }>(prompt)

    const stored: Memory[] = []
    for (const m of parsed.memories ?? []) {
      if (!m.memory?.trim()) continue
      const created = await addMemory(
        m.memory.trim(),
        m.category ?? 'general',
        Math.min(5, Math.max(1, Math.round(m.importance ?? 1))),
      )
      if (created) stored.push(created)
    }
    return stored
  } catch (err) {
    console.log('[v0] extractAndStoreMemories error:', (err as Error).message)
    return []
  }
}
