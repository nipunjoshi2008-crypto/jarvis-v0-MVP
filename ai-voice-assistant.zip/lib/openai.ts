const OPENAI_URL = 'https://api.openai.com/v1/chat/completions'
const MODEL = 'gpt-4o-mini'

interface ChatMsg {
  role: 'system' | 'user' | 'assistant'
  content: string
}

function apiKey(): string {
  const key = process.env.OPENAI_API_KEY
  if (!key) throw new Error('OPENAI_API_KEY is not set')
  return key
}

export class OpenAIError extends Error {
  status: number
  friendly: string
  constructor(status: number, raw: string) {
    super(`OpenAI request failed: ${status} ${raw}`)
    this.status = status
    this.friendly = friendlyMessage(status, raw)
  }
}

function friendlyMessage(status: number, raw: string): string {
  const lower = raw.toLowerCase()
  if (status === 429 && lower.includes('quota')) {
    return 'My reasoning core is offline — the OpenAI account has no remaining credits. Please top up the balance to restore full function, sir.'
  }
  if (status === 429) {
    return 'I am being rate-limited by the reasoning core. A brief moment, then try again, sir.'
  }
  if (status === 401) {
    return 'The OpenAI credentials appear to be invalid. Please verify the API key, sir.'
  }
  return 'Apologies, sir — I encountered a fault reaching the reasoning core.'
}

/** One-shot completion that must return JSON (used by memory extraction). */
export async function callOpenAIJSON<T>(prompt: string): Promise<T> {
  const res = await fetch(OPENAI_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey()}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: MODEL,
      temperature: 0.2,
      response_format: { type: 'json_object' },
      messages: [{ role: 'user', content: prompt }],
    }),
  })

  if (!res.ok) {
    throw new Error(`OpenAI JSON call failed: ${res.status} ${await res.text()}`)
  }

  const data = await res.json()
  const content = data.choices?.[0]?.message?.content ?? '{}'
  return JSON.parse(content) as T
}

/**
 * Streaming chat completion. Returns a ReadableStream of raw text tokens
 * (already decoded from SSE), suitable for piping to the client.
 */
export async function streamOpenAIChat(
  messages: ChatMsg[],
): Promise<ReadableStream<Uint8Array>> {
  const upstream = await fetch(OPENAI_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey()}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: MODEL,
      temperature: 0.6,
      stream: true,
      messages,
    }),
  })

  if (!upstream.ok || !upstream.body) {
    throw new Error(`OpenAI stream failed: ${upstream.status} ${await upstream.text()}`)
  }

  const reader = upstream.body.getReader()
  const decoder = new TextDecoder()
  const encoder = new TextEncoder()
  let buffer = ''

  return new ReadableStream<Uint8Array>({
    async pull(controller) {
      const { done, value } = await reader.read()
      if (done) {
        controller.close()
        return
      }
      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() ?? ''

      for (const line of lines) {
        const trimmed = line.trim()
        if (!trimmed.startsWith('data:')) continue
        const payload = trimmed.slice(5).trim()
        if (payload === '[DONE]') {
          controller.close()
          return
        }
        try {
          const json = JSON.parse(payload)
          const token = json.choices?.[0]?.delta?.content
          if (token) controller.enqueue(encoder.encode(token))
        } catch {
          // ignore keep-alive / partial chunks
        }
      }
    },
    cancel() {
      reader.cancel().catch(() => {})
    },
  })
}
