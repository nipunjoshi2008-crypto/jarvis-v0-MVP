import type { Source } from './types'

/**
 * Web search abstraction. Currently backed by SearchApi.io (Google engine),
 * but the shape is provider-agnostic so it can be swapped later.
 */
export async function webSearch(
  query: string,
  limit = 5,
): Promise<Source[]> {
  const apiKey = process.env.SEARCH_API_KEY
  if (!apiKey) {
    console.log('[v0] webSearch: SEARCH_API_KEY missing, returning empty')
    return []
  }

  try {
    const url = new URL('https://www.searchapi.io/api/v1/search')
    url.searchParams.set('engine', 'google')
    url.searchParams.set('q', query)
    url.searchParams.set('num', String(limit))
    url.searchParams.set('api_key', apiKey)

    const res = await fetch(url.toString(), {
      headers: { Accept: 'application/json' },
    })

    if (!res.ok) {
      console.log('[v0] webSearch failed:', res.status, await res.text())
      return []
    }

    const data = (await res.json()) as {
      answer_box?: { answer?: string; snippet?: string }
      organic_results?: Array<{
        title?: string
        link?: string
        snippet?: string
      }>
    }

    const results: Source[] = []

    // Prefer an answer box if present.
    if (data.answer_box?.answer || data.answer_box?.snippet) {
      results.push({
        title: 'Featured answer',
        url: data.organic_results?.[0]?.link ?? '',
        snippet: data.answer_box.answer ?? data.answer_box.snippet,
      })
    }

    for (const r of data.organic_results ?? []) {
      if (!r.link) continue
      results.push({
        title: r.title ?? r.link,
        url: r.link,
        snippet: r.snippet,
      })
      if (results.length >= limit) break
    }

    return results
  } catch (err) {
    console.log('[v0] webSearch error:', (err as Error).message)
    return []
  }
}

/**
 * Heuristic: decide whether a query likely needs live web data.
 * The model also gets a search tool, but this gives a fast client hint.
 */
export function looksLikeSearchQuery(text: string): boolean {
  const t = text.toLowerCase()
  return /\b(latest|news|today|current|weather|price|stock|score|who won|when is|release date|202\d)\b/.test(
    t,
  )
}
