import { createClient, type SupabaseClient } from '@supabase/supabase-js'

/**
 * Server-only Supabase client using the service role key.
 * This bypasses RLS. NEVER import this in client components.
 * The single-shared-user MVP relies on this for all persistence.
 */
let cached: SupabaseClient | null = null

export function getAdminClient(): SupabaseClient {
  if (cached) return cached

  const url = process.env.SUPABASE_URL ?? process.env.NEXT_PUBLIC_SUPABASE_URL
  const serviceKey =
    process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SECRET_KEY

  if (!url || !serviceKey) {
    throw new Error(
      'Supabase admin client is not configured: missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY.',
    )
  }

  cached = createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
  return cached
}

// The single implicit user for the no-login MVP.
export const DEFAULT_USER_ID = 'default-user'
