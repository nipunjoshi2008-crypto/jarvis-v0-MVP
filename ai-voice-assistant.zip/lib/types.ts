export type Role = 'user' | 'assistant' | 'system'

export interface Source {
  title: string
  url: string
  snippet?: string
}

export interface Message {
  id: string
  conversation_id: string
  role: Role
  content: string
  sources?: Source[] | null
  created_at: string
}

export interface Conversation {
  id: string
  user_id: string
  title: string
  created_at: string
  updated_at: string
}

export interface Memory {
  id: string
  user_id: string
  memory: string
  category: string
  importance: number
  created_at: string
  updated_at: string
}
